# Twitchy Hue

## Quick setup

Make a copy of config_example.txt and rename it to config.txt
Open it in notepad or another text editor and fill in the required sections
Run twitchy_hue.exe
*NOTE You will need to press the link button on your phillips hue bridge the first time you run this!
